package com.example.thequizzler;

import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.Button;
import android.os.Bundle;
import android.view.View;
public class MainActivity extends AppCompatActivity { //Creates the class with the name MainActivity and inherits AppCompatActivity

    private Button mTrueButton; //it makes the true button unaccessible or unchangeable.
    private Button mFalseButton; //it makes the false button unsccessible or unchangeable.
    private Button mNextButton; //it makes the next button unaccesible or unchangeable.
    private TextView mQuestionTextView; //it makes the text unchangeable.

    private Question[]mQuestionBank=new Question[]{
            new Question(R.string.question_madison, true),
            new Question(R.string.question_milwaukee, false),
            new Question(R.string.question_chicago, true),
            new Question(R.string.question_bird, true),
            new Question(R.string.question_tree, false),
            new Question(R.string.question_midwest, false),
    };

    private int mCurrentIndex=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mQuestionTextView = (TextView) findViewById(R.id.question_text_view);
        int question = mQuestionBank[mCurrentIndex].getmTextResId();
        mQuestionTextView.setText(question);

        mTrueButton = (Button) findViewById(R.id.true_button);
        mTrueButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer(true);
            }
        });
        mFalseButton = (Button) findViewById(R.id.false_button);
        mFalseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer(false);
            }


        });
        mNextButton = (Button) findViewById(R.id.next_button);
        mNextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mCurrentIndex == mQuestionBank.length - 1) {
                    mCurrentIndex=0;
                }
                else{
                    mCurrentIndex++;
                }
                UpdateQuestion();
            }
        });
        UpdateQuestion();

    }
        private void UpdateQuestion() {
            int question = mQuestionBank[mCurrentIndex].getmTextResId();
            mQuestionTextView.setText(question);
        }

        private void checkAnswer(boolean userPressedTrue) { //Accepts a boolean ID if the user pressed True or False
             boolean answerIsTrue = mQuestionBank[mCurrentIndex].isAnswerTrue(); // Checks if the answer is saved as being true or false.

             int messageResId = 0;

             if (userPressedTrue == answerIsTrue) {
                 messageResId = R.string.correct_toast; // Determines if the user is correct or not and stores the correct or incorrect toast.
             } else {
                 messageResId = R.string.incorrect_toast;
             }

             Toast.makeText(this, messageResId, Toast.LENGTH_SHORT).show(); // Instructs the Toast to display on the View Layer.
        }
    }


